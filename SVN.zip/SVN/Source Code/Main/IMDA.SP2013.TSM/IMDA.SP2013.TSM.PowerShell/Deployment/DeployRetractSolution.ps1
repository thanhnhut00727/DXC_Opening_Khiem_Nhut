<# 
.DESCRIPTION 
    - Run this script to deploy/retract the farm level solution and activate/deactivate features 
  
.ASSUMPTION 
 - Batch files, log files, and WSPs exists in same directory during deployment process 
 
.NOMENCALTURE 
 -- green indicate major step 
 -- yellow indicate detailed info 
 -- red indicate errors 
  
.THIS BATCH FILE WILL ALLOW 
 - Parameters passed in from the batch file 
 - Loading SharePoint PowerShell Plugin - Check if its already been loaded 
 - Logging of Powershell script execution transcript, New file gets created for each run 
 - Solution Deploy or Retract in single click 
 - Waiting for  timer job execution while deploying and retracting solution 
 - Nullable $siteFeatureNames and $webFeatureNames parameters to support deployment only option, no activation of features 
 - Support Multiple Site and Web Level Features - Site feature and web features are passed in as array paramters 
 - Support Activation of features at Multiple Webs - Activate/Deactivate Web Level features on all webs in site collection 
 - Check for webapplication level resources to deploy or retract solutions at the web application level or all web application level 
 
#> 
 
param ( 
  
[string]$solutionName, 
[string[]]$webUrls, 
[string]$siteUrl, 
[string]$webAppUrl, 
[string[]]$webFeatureNames, 
[string[]]$siteFeatureNames, 
[string[]]$webAppFeatureNames, 
[string]$logFileName, 
[string]$action 
) 

$solutionName = "IMDA.SP2013.TSM.wsp"

$webAppUrl = 'http://soe532:10406'
$siteUrl = 'http://soe532:10406/sites/tsm1'
$webUrls = @('http://soe532:10406/sites/tsm1/sub1')
$siteFeatureNames = @('IMDA.SP2013.TSM.Infrastructure')
$webFeatureNames = @('IMDA.SP2013.TSM')
$action = "Deploy"
$logFileName = "DeploySolution"
 
# Definition of main function 
function main() { 
 # find the current directory 
 $currentDirectory = Get-Location 
   
 # delete existing logfile 
 $logFilePath = "$currentDirectory\$logFileName" 
 if (Test-Path $logFilePath) 
 { 
  Remove-Item $logFilePath 
 } 
  
 # create new log file and start logging 
 Start-Transcript $logFilePath 
 
# region :- check to ensure Microsoft.SharePoint.PowerShell is loaded 
Write-Host "Loading SharePoint Commandlets" 
 
Add-PSSnapin Microsoft.SharePoint.PowerShell -errorvariable err1 -erroraction SilentlyContinue 
if($err1) 
{ 
write-host -ForegroundColor Yellow "Either SP Powershell snapin is already loaded or there is some error loading Powershell Snapin for sharepoint" 
} 
else 
{ 
Write-Host -ForegroundColor Green " Commandlets Loaded ... Loading Variables" 
Write-Host 
} 
 
 
#endregion 
  
 # deploy the solution 
 if ($action -eq "Deploy") 
 { 
  Write-Host "Step 1 - Add Solution Package: " $solutionName -foregroundcolor Green 
  AddSolution 
  
  Write-Host "Step 2 - Deploy Solution Package: " $solutionName -foregroundcolor Green 
  InstallSolution 
  
  Write-Host "Step 3 - Timer Job to deploy the Solution Package" -foregroundcolor Green 
  Wait4TimerJob 
 
  Write-Host "Step 4 - Activate Site Collection Level Features" -foregroundcolor Green 
  ActivateSiteFeatures 
 
  Write-Host "Step 5 - Activate Web Level Features" -foregroundcolor Green 
  ActivateWebFeatures  
 
  Write-Host "Step 6 - Activate Web Application Level Features" -foregroundcolor Green 
  ActivateWebAppFeatures 

  Write-Host "Step 7 - Deploy Timer Jobs" -foregroundcolor Green 
  Create-PriorContractEndTimerJob 
 
  Write-Host "Step 8 - Restart Timer Service on all servers" -foregroundcolor Green 
  restart-service sptimerv4 
 
  write-host 
  write-host "Finished Solution Deployment..." -foregroundcolor Green 
 
  write-host 
  write-host "Please activate the necessary features manually, if there was some error activating some features..." -foregroundcolor Green 
 
  write-host 
  write-host "Please restart timer service manually, on the servers, where there was some problem restarting it..." -foregroundcolor Green 
 } 
  
 # retract the solution 
 if ($action -eq "Retract") 
 { 
  write-host "Step 1 - Deactivate web level features: " -foregroundcolor Green 
  DeactivateWebFeatures 
  
  Write-Host "Step 2 - Uninstall Solution Package: " $solutionName -foregroundcolor Green 
  UnInstallSolution 
  
  Write-Host "Step 3 - Timer Job to Retract the Solution Package" -foregroundcolor Green 
  Wait4TimerJob 
  
  Write-Host "Step 4 - Remove Solution Package: " $solutionName -foregroundcolor Green 
  RemoveSolution 
 
  write-host 
  write-host "Finished Solution Retraction..." -foregroundcolor Green 
 } 
  
 # stop the logging 
 Stop-Transcript 
} 
 
# Adds a SharePoint solution package to the farm Solution gallery. 
function AddSolution() 
{ 
 $solution = Get-SPSolution | where-object {$_.Name -eq $solutionName} 
 if ($solution -eq $null) 
 { 
  Write-Host "Adding solution package" -foregroundcolor Yellow 
  $solutionPath = "$currentDirectory\$solutionName" 
  Add-SPSolution -LiteralPath $solutionPath -Confirm:$false 
 } 
} 
 
# Deploy the solution package 
function InstallSolution() 
{ 
 $solution = Get-SPSolution | where-object {$_.Name -eq $solutionName} 
 $solutionId = $solution.Id 
 if ($solution -ne $null) 
 { 
  $solutionDeployed = Get-SPSolution -Identity $solutionId | where-object {$_.Deployed -eq "False"} 
  if ($solutionDeployed -eq $null) 
  { 
   if ( $solution.ContainsWebApplicationResource ) 
   { 
    Write-Host "Deploying solution package to web application: " $webAppUrl -foregroundcolor Yellow 
    Install-SPSolution -Identity $solutionName -WebApplication $webAppUrl -GACDeployment -FullTrustBinDeployment -Confirm:$false 
   } 
   else 
   { 
    Write-Host "Deploying solution package to all web applications" -foregroundcolor Yellow 
    Install-SPSolution -Identity $solutionName -GACDeployment -Confirm:$false 
   } 
  } 
 } 
} 
 
# Activate the Web Application level features 
function ActivateWebAppFeatures() 
{ 
 if ($webAppFeatureNames -ne $null) 
 { 
  $spWebApp = Get-SPWebApplication $webAppUrl 
  foreach($webAppFeatureName in $webAppFeatureNames) 
  { 
   Write-Host "Trying to Activate Web Application Level Feature: " [$webAppFeatureName] -foregroundcolor Yellow 
   $webAppFeature = Get-SPFeature -WebApplication $spWebApp.url | where-object {$_.displayname -eq $webAppFeatureName} 
   if ($webAppFeature -eq $null) 
   { 
    Enable-SPFeature -identity $webAppFeatureName -URL $spWebApp.url -Confirm:$false -ErrorVariable err7 -ErrorAction SilentlyContinue 
     if($err7) 
     { 
    Write-Host "Error occurred while activating web app level feature " [$webAppFeatureName] " " -foregroundcolor Red 
     } 
     else 
     { 
    Write-Host "Successfully Activated web app level feature " [$webAppFeatureName] " " -foregroundcolor Green 
     } 
   } 
   else 
   { 
    Write-Host "Web app feature " [$webAppFeatureName] " is already activated " -foregroundcolor Yellow 
   } 
   write-host 
  } 
 
 } 
} 
 
# Activate the Site level features 
function ActivateSiteFeatures() 
{ 
 if ($siteFeatureNames -ne $null) 
 { 
  $spSite = Get-SPSite $siteUrl  
  foreach($siteFeatureName in $siteFeatureNames) 
  { 
   Write-Host "Trying to Activate Site Collection Level Feature: " [$siteFeatureName] -foregroundcolor Yellow 
   $siteFeature = Get-SPFeature -site $spSite.url | where-object {$_.displayname -eq $siteFeatureName} 
   if ($siteFeature -eq $null) 
   { 
 
    Enable-SPFeature -identity $siteFeatureName -URL $spSite.url -Confirm:$false -ErrorVariable err6 -ErrorAction SilentlyContinue 
     if($err6) 
     { 
    Write-Host "Error occurred while activating site collection level feature " [$siteFeatureName] " " -foregroundcolor Red 
     } 
     else 
     { 
    Write-Host "Successfully Activated site collection level feature " [$siteFeatureName] " " -foregroundcolor Green 
     } 
   } 
   else 
   { 
    Write-Host "Site collection feature " [$siteFeatureName] " is already activated " -foregroundcolor Yellow 
   } 
   write-host 
  }  
  $spSite.Dispose() 
 } 
} 
 
# Activate the Web level features 
function ActivateWebFeatures() 
{ 
 if ($webFeatureNames -ne $null) 
 { 
  if($webUrls -ne $null) 
  { 
  foreach($webUrl in $webUrls) 
  { 
  $spWeb = Get-SPWeb $webUrl 
  
   foreach($webFeatureName in $webFeatureNames) 
   {  
    write-host 
    Write-Host "Trying to Activate Web Level Feature: " $webFeatureName at $webUrl -foregroundcolor Yellow 
    $webFeature = Get-SPFeature -web $spWeb.url | where-object {$_.displayname -eq $webFeatureName} 
    if ($webFeature -eq $null) 
    { 
    
     Enable-SPFeature -identity $webFeatureName -URL $spWeb.url -Confirm:$false -ErrorVariable err5 -ErrorAction SilentlyContinue 
     if($err5) 
     { 
    Write-Host "Error occurred while activating web level feature " [$webFeatureName] "" -foregroundcolor Red 
     } 
     else 
     { 
    Write-Host "Successfully Activated web level feature " [$webFeatureName] "at $webUrl" -foregroundcolor Green 
     } 
    } 
    else 
    { 
     Write-Host "web level feature " [$webFeatureName] " is already activated " at $webUrl -foregroundcolor Yellow 
    } 
    write-host 
 } 
 } 
  $spWeb.Dispose() 
  } 
 } 
} 
 
 
# Retract the solution package 
function UnInstallSolution() 
{ 
 $solution = Get-SPSolution | where-object {$_.Name -eq $solutionName} 
 $solutionId = $solution.Id 
 if ($solution -ne $null) 
 { 
  $solutionDeployed = Get-SPSolution -Identity $solutionId | where-object {$_.Deployed -eq "True"} 
  if ($solutionDeployed -ne $null)   
  { 
   if ( $solution.ContainsWebApplicationResource ) 
   { 
    Write-Host "Retracting solution package from web application: " $webAppUrl -foregroundcolor Yellow 
    UnInstall-SPSolution -Identity $solutionName -WebApplication $webAppUrl -Confirm:$false 
   } 
   else 
   { 
    Write-Host "Retracting solution package from all web applications" -foregroundcolor Yellow 
    UnInstall-SPSolution -Identity $solutionName -Confirm:$false 
   } 
  } 
 } 
} 
 
# Remove the solution package 
# Deletes a SharePoint solution from a farm solution gallery 
function RemoveSolution() 
{ 
 $solution = Get-SPSolution | where-object {$_.Name -eq $solutionName} 
 if ($solution -ne $null) 
 { 
  Write-Host "Deleting the solution package" -foregroundcolor Yellow 
  Remove-SPSolution $solutionName -Confirm:$false 
 } 
} 
 
# Wait for timer job during deploy and retract 
function Wait4TimerJob() 
{ 
 $solution = Get-SPSolution | where-object {$_.Name -eq $solutionName} 
 if ($solution -ne $null) 
 { 
  $counter = 1  
  $maximum = 50  
  $sleeptime = 2 
  
  Write-Host "Waiting to finish soultion timer job" 
  while( ($solution.JobExists -eq $true ) -and ( $counter -lt $maximum ) ) 
  {  
   Write-Host "Please wait..." 
   sleep $sleeptime 
   $counter++  
  } 
  
  Write-Host "Finished the solution timer job"   
 } 
} 
 
# Deactivate the Web level features 
function DeactivateWebFeatures() 
{ 
 if ($webFeatureNames -ne $null) 
 { 
  
  #Cycle through all webs in the collection and deactivate all the features 
  foreach($webUrl in $webUrls) 
  { 
  $spWeb = Get-SPWeb $webUrl 
   foreach($webFeatureName in $webFeatureNames) 
   {  
    Write-Host "Trying to Deactivate Web Level Features: " $webFeatureName at $webUrl -foregroundcolor Yellow 
    $webFeature = Get-SPFeature -web $spWeb.url | where-object {$_.displayname -eq $webFeatureName} 
    if ($webFeature -ne $null) 
    { 
     Write-Host "Deactivating " $webFeatureName " at " $spWeb.url -foregroundcolor Yellow 
     Disable-SPFeature -identity $webFeatureName -URL $spWeb.url -Confirm:$false -errorVariable err10 -errorAction SilentlyContinue 
     if($err10) 
     { 
      write-host -foregroundcolor Red "Error occurred while deactivating web level feature $webFeatureName at $webUrl" 
     } 
     else 
     { 
      write-host -foregroundcolor Green "Successfully deactivated $webFeatureName at $webUrl" 
     } 
    } 
    else 
    { 
     write-host -foregroundcolor Yellow "$webFeatureName is already deactivated at $webUrl" 
    } 
   } 
   write-host 
  } 
  
  $spWeb.Dispose() 
 } 
} 

function Create-PriorContractEndTimerJob()
{
    #Load timer jobs assembly, so it can be used in my script 
	[System.Reflection.Assembly]::Load("IMDA.SP2013.TSM, Version=1.0.0.0, Culture=neutral, PublicKeyToken=254230baec09928f")

    $web = Get-SPWeb($siteUrl)

	$jobName = "IMDA_TSM Prior Contract End Date Notification Job"
 
	#Delete the timer job if it already exists
	Get-SPTimerJob | where { $_.TypeName -eq "IMDA.SP2013.TSM.TimerJobs.PriorContractEndTimerJob" } | % { $_.Delete() }
 
	#Create an execution schedule
	[Microsoft.SharePoint.SPSchedule] $schedule = [Microsoft.SharePoint.SPSchedule]::FromString("Daily between 0:00:00 and 00:30:00") 
 
	#Instantiate the custom timer job object
	[IMDA.SP2013.TSM.TimerJobs.PriorContractEndTimerJob] $job = New-Object "IMDA.SP2013.TSM.TimerJobs.PriorContractEndTimerJob" ($jobName,(Get-SPWebApplication $webAppUrl))
	$job.HomeSiteUrl = $webUrls[0];
 
	$job.Schedule = $schedule
	$job.Title = $jobName
 
	$job.Update($true)
 
	Get-SPTimerJob -Identity $jobName | Start-SPTimerJob
}
 
#Run the Main Function 
main 