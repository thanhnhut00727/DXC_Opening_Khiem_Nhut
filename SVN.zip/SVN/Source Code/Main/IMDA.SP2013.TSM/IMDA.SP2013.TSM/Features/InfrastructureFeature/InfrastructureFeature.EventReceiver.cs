using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using IMDA.SP2013.TSM.Providers.Constants;
using System.Xml.Linq;
using IMDA.SP2013.TSM.Providers.Helpers;
using IMDA.SP2013.TSM.Providers.Entities;
using System.Collections.Generic;
using System.IO;
using System.Collections;
using IMDA.SP2013.TSM.Providers.ProvisionHandlers;
using Microsoft.SharePoint.Administration;
using IMDA.SP2013.TSM.TimerJobs;

namespace IMDA.SP2013.TSM.Features.InfrastructureFeature
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("968a79e7-a025-4614-8119-7206636941bd")]
    public class InfrastructureFeatureEventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPSite site = properties.Feature.Parent as SPSite;
            //SPWebApplication currentWebApp = site.WebApplication;

            string filePath = string.Empty;
            
            using (SPWeb elevatedWeb = site.OpenWeb())
            {
                //Upload List Templates
                filePath = ApplicationSettings.SPHiveFolder + ApplicationSettings.MetadataPath + "ListTemplate.xml";
                ListProvision.ProvisionListTemplates(elevatedWeb, filePath);    
                
                //Provision Permission
                filePath = ApplicationSettings.SPHiveFolder + ApplicationSettings.MetadataPath + "Permission.xml";
                PermissionProvision.ProvisioningPermission(elevatedWeb, filePath); 
            }                                
        }
        
        // Uncomment the method below to handle the event raised before a feature is deactivated.

        //public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}
