﻿using IMDA.SP2013.TSM.Providers.Constants;
using IMDA.SP2013.TSM.Providers.Helpers;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace IMDA.SP2013.TSM.Providers.DataAccess
{
    public static class SharePointHelper
    {
        #region Public Methods
        public static string GetValueByKey(Dictionary<string, string> fields, string key)
        {
            if (fields.ContainsKey(key))
                return fields[key];

            return string.Empty;
        }

        public static void GetFieldValues(Dictionary<string, string> fields, SPItemEventProperties properties, List<string> fieldNames)
        {
            string fieldValue = string.Empty;
            foreach (string fName in fieldNames)
            {
                fieldValue = GetFieldValue(properties, fName);

                if (!string.IsNullOrEmpty(fieldValue))
                    fields.Add(fName, fieldValue);
            }
        }

        public static string GetFieldValue(SPItemEventProperties properties, string fName)
        {
            if (properties.BeforeProperties[fName] != null)
                return properties.BeforeProperties[fName].ToString();

            if (properties.AfterProperties[fName] != null)
                return properties.AfterProperties[fName].ToString();

            if (properties.ListItem != null && properties.ListItem[fName] != null)
                return properties.ListItem[fName].ToString();

            return string.Empty;
        }

        public static string GetConfigurationValue(SPWeb web, string listName, string keyFieldName, string valueFieldName, string key)
        {
            string value = string.Empty;

            try
            {
                SPList oList = web.Lists[listName];
                if (oList != null)
                {
                    SPQuery qry = new SPQuery();
                    qry.Query = String.Format(@"
                       <Where>       
                                <Eq>
                                    <FieldRef Name='{0}'/>
                                    <Value Type='Text'>{1}</Value>
                                </Eq>                             
                        </Where>",
                        keyFieldName,
                        key);
                    qry.RowLimit = 1;

                    SPListItemCollection oListItems = oList.GetItems(qry);
                    if (oListItems[0] != null)
                    {
                        SPListItem item = oListItems[0];
                        return item[valueFieldName].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex);
            }

            return null;
        }

        public static string GetListItemUrl(SPListItem listItem, string webRelativeUrl)
        {
            if (listItem != null)
            {
                string parentWebUrl = listItem.ParentList.ParentWeb.Url;
                if (!string.IsNullOrEmpty(webRelativeUrl) && parentWebUrl.IndexOf(webRelativeUrl) > 0)
                    parentWebUrl = parentWebUrl.Substring(0, parentWebUrl.Length - webRelativeUrl.Length);

                string displayFormUrl = listItem.ParentList.DefaultDisplayFormUrl;
                string itemIdQuery = "?ID=" + listItem.ID;
                string fullUrl = parentWebUrl.EndsWith("/") ? parentWebUrl + displayFormUrl + itemIdQuery : parentWebUrl + "/" + displayFormUrl + itemIdQuery;

                return fullUrl;
            }

            return string.Empty;
        }        

        public static bool CompareTwoDates(DateTime fromdate, DateTime todate)
        {
            if (fromdate == DateTime.MinValue || todate == DateTime.MinValue)
                return false;

            CultureInfo originalCulture = Thread.CurrentThread.CurrentCulture;
            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");

            string fromDateStr = fromdate.ToShortDateString();
            string toDateStr = todate.ToShortDateString();

            DateTime fromD = DateTime.Parse(fromDateStr);
            DateTime toD = DateTime.Parse(toDateStr);

            if (fromD == toD)
                return true;

            // Restore original culture.
            Thread.CurrentThread.CurrentCulture = originalCulture;

            return false;
        }

        public static DateTime GetDateTimeFieldValue(SPWeb web, SPListItem item, string fieldName)
        {
            DateTime result = DateTime.MinValue;

            if (item != null && item[fieldName] != null)
            {
                CultureInfo originalCulture = Thread.CurrentThread.CurrentCulture;
                Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");

                string fieldDateStr = item[fieldName].ToString();
                if (!string.IsNullOrEmpty(fieldDateStr))
                    result = Convert.ToDateTime(fieldDateStr);

                // Restore original culture.
                Thread.CurrentThread.CurrentCulture = originalCulture;
            }

            return result;
        }

        public static DateTime GetDateTimeFieldValue(SPWeb web, string fieldValue)
        {
            DateTime result = DateTime.MinValue;

            if (!string.IsNullOrEmpty(fieldValue))
            {
                CultureInfo originalCulture = Thread.CurrentThread.CurrentCulture;
                Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");

                result = Convert.ToDateTime(fieldValue);

                // Restore original culture.
                Thread.CurrentThread.CurrentCulture = originalCulture;
            }

            return result;
        }

        public static void DeleteAllItemsInList(SPSite spSite, SPWeb web, string listName)
        {
            SPList list = web.Lists[listName];
            if (list != null)
            {
                SPQuery qry = new SPQuery();
                qry.Query = String.Format(@"
                       <Where>       
                                <IsNotNull>
                                    <FieldRef Name='Title'/>
                                </IsNotNull>   
                             
                        </Where>");
                qry.RowLimit = 100;

                SPListItemCollection items = list.GetItems(qry);
                if (items.Count > 0)
                {
                    StringBuilder deletebuilder = new StringBuilder();

                    deletebuilder.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Batch>");
                    string command = "<Method><SetList Scope=\"Request\">" + list.ID +
                        "</SetList><SetVar Name=\"ID\">{0}</SetVar><SetVar Name=\"Cmd\">Delete</SetVar></Method>";

                    foreach (SPListItem item in items)
                    {
                        deletebuilder.Append(string.Format(command, item.ID.ToString()));
                    }

                    deletebuilder.Append("</Batch>");
                    spSite.RootWeb.ProcessBatchData(deletebuilder.ToString());
                }
            }
        }

        public static SPContentType GetContentType(SPWeb web, string ctId)
        {
            SPContentTypeId ctypeId = new SPContentTypeId(ctId);
            SPContentTypeId matchId = web.ContentTypes.BestMatch(ctypeId);
            SPContentType cType = web.ContentTypes[matchId];
            return cType;
        }

        public static void AddNewItemToSystemParametersList(SPWeb web, string listName, string contentTypeId, Dictionary<string, string> defaultData)
        {
            SPList list = web.Lists[listName];
            if (list != null)
            {
                foreach (var item in defaultData)
                {
                    SPListItem newItem = list.AddItem();

                    newItem[Fields.ContentTypeId] = contentTypeId;

                    newItem[Fields.Title] = item.Key;
                    newItem[Fields.KeywordValues] = item.Value;

                    newItem.Update();
                }
            }
        }

        public static void UpdateDateTimeField(SPItemEventProperties properties, string fieldName, DateTime selectedDate)
        {
            if (selectedDate != DateTime.MinValue)
                properties.AfterProperties[fieldName] = SPUtility.CreateISO8601DateTimeFromSystemDateTime(selectedDate); // ToString("yyyy-MM-ddThh:mm:ssZ"); 
        }

        public static void UpdateDateTimeField(SPListItem item, string fieldName, DateTime selectedDate)
        {
            if (selectedDate != DateTime.MinValue)
                item[fieldName] = SPUtility.CreateISO8601DateTimeFromSystemDateTime(selectedDate); // ToString("yyyy-MM-ddThh:mm:ssZ"); 
        }

        public static SPList GetListByUrl(SPWeb web, string listUrl)
        {
            try
            {
                if (!listUrl.StartsWith("/"))
                    listUrl = "/" + listUrl;

                return web.GetList(web.Url + listUrl);
            }
            catch { }

            return null;
        }

        public static SPListItem GetListItem(SPWeb web, string listTitle, int itemId)
        {
            SPList list = web.Lists.TryGetList(listTitle);
            if (list != null)
            {
                return list.GetItemByIdAllFields(itemId);
            }
            return null;
        }
        #endregion

        #region SPUser fucntions
        public static string GetEmail(SPWeb web, string fieldValue)
        {
            var separator = new string[] { ";#" };
            var userId = int.Parse(fieldValue.Split(separator, StringSplitOptions.RemoveEmptyEntries)[0]);
            SPUser principle = web.Users.GetByID(userId);
            if (principle != null)
                return principle.Email;

            return string.Empty;
        }
        public static SPUser GetUserByUserName(SPWeb web, string userName)
        {
            try
            {
                return web.EnsureUser(userName);
            }
            catch
            {
                if (userName.IndexOf(";#") > 0)
                {
                    string name = userName.Split(new string[] { ";#" }, StringSplitOptions.None)[1];
                    if (!string.IsNullOrEmpty(name))
                        return web.EnsureUser(name);
                }
                return null;
            }
        }

        public static SPUser GetSPUserFromListItem(SPWeb web, SPListItem item, string fieldName)
        {
            string wrUserName = item[fieldName] != null ? item[fieldName].ToString() : string.Empty;
            if (!string.IsNullOrEmpty(wrUserName))
                return SharePointHelper.GetUserByUserName(web, wrUserName);

            return null;
        }

        public static SPListItem QueryListItem(SPWeb web, string listName, SPQuery qry)
        {
            SPListItem item = null;

            SPList oList = web.Lists[listName];
            if (oList != null)
            {
                SPListItemCollection oListItems = oList.GetItems(qry);
                if (oListItems != null && oListItems[0] != null)
                    item = oListItems[0];
            }

            return item;
        }

        private static SPUserCollection GetUserByGroup(SPWeb web, string groupName)
        {
            SPGroupCollection groups = web.SiteGroups;

            var foundGroups = groups.GetCollection(new string[] { groupName });
            if (foundGroups.Count > 0 && foundGroups[0].Users != null)
            {
                return foundGroups[0].Users;
            }

            return null;
        }

        public static SPUser GetUserFromAfterProperties(object property, SPWeb web)
        {
            SPUser user = null;

            string fieldValue = property == null ? null : property.ToString();

            if (fieldValue != null && fieldValue.Contains(";#"))
            {
                string loginName = fieldValue.Contains(";#") ? fieldValue.Split(new string[] { ";#" }, StringSplitOptions.None)[1] : null;
                user = web.EnsureUser(loginName);
            }
            else
            {
                try
                {
                    if (property != null)
                        user = new SPFieldUserValue(web, property.ToString()).User;
                }
                catch
                {
                    user = web.EnsureUser(property.ToString());
                }
            }

            return user;
        }

        public static SPPrincipal GetPrinciple(SPWeb web, string gr)
        {
            SPPrincipal p = null;
            if (!string.IsNullOrEmpty(gr))
            {
                p = web.SiteGroups.GetByName(gr);
            }
            return p;
        }

        public static SPGroup GetGroupByName(SPWeb web, string groupName)
        {
            SPGroupCollection groups = web.SiteGroups;

            var foundGroups = groups.GetCollection(new string[] { groupName });
            if (foundGroups != null && foundGroups.Count > 0)
            {
                return foundGroups[0];
            }

            return null;
        }

        /// <summary>
        /// Ensure a principle object returned from user field
        /// </summary>
        /// <param name="web"></param>
        /// <param name="u"></param>
        /// <returns></returns>
        public static SPPrincipal GetPrinciple(SPWeb web, SPFieldUserValue u)
        {
            SPPrincipal p = u.User;
            if (p == null)
            {
                p = web.SiteGroups.GetByName(u.LookupValue);
            }
            return p;
        }
        /// <summary>
        /// Ensure a list of principle objects returned from user field collection
        /// </summary>
        /// <param name="web"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public static List<SPUser> GetUserCollection(SPWeb web, object value)
        {
            var principles = new List<SPUser>();
            if (value == null) return principles;

            if (value is SPFieldUserValueCollection)
            {
                var userValueCollection = value as SPFieldUserValueCollection;
                foreach (var u in userValueCollection)
                {
                    SPUser p = GetUserByUserName(web, u.ToString());
                    if (p != null) principles.Add(p);
                }
            }
            else
            {
                var u = value as SPFieldUserValue;
                SPUser p = GetUserByUserName(web, u.ToString());
                if (p != null) principles.Add(p);
            }

            return principles;
        }

        public static List<string> GetEmailsByGroup(SPWeb web, string groupName)
        {
            List<string> results = new List<string>();

            SPUserCollection users = GetUserByGroup(web, groupName);
            foreach (SPUser user in users)
            {
                if (!string.IsNullOrEmpty(user.Email))
                    results.Add(user.Email);
            }

            return results;
        }

        public static Dictionary<string, string> InitilizeMultiUserFieldValue(List<SPUser> users)
        {
            Dictionary<string, string> result = new Dictionary<string, string>();
            StringBuilder values = new StringBuilder();
            StringBuilder sPFieldUsers = new StringBuilder();
            foreach (SPUser user in users)
            {
                string loginAccount = user.LoginName.Replace("i:0#.w|", "");
                values.AppendFormat("{0};#", loginAccount);
                sPFieldUsers.AppendFormat("{0};#{1};#", user.ID, user.Name);
            }

            result.Add("LoginNames", values.ToString());
            result.Add("Users", sPFieldUsers.ToString());

            return result;
        }

        public static Dictionary<string, string> InitilizeMultiUserFieldValue(List<SPGroup> groups)
        {
            Dictionary<string, string> result = new Dictionary<string, string>();
            StringBuilder values = new StringBuilder();
            StringBuilder sPFieldUsers = new StringBuilder();
            foreach (SPGroup group in groups)
            {
                string loginAccount = group.Name.Replace("i:0#.w|", "");
                values.AppendFormat("{0};#", loginAccount);
                sPFieldUsers.AppendFormat("{0};#{1};#", group.ID, group.Name);
            }

            result.Add("LoginNames", values.ToString());
            result.Add("Groups", sPFieldUsers.ToString());

            return result;
        }

        public static void UpdateUserField(SPListItem item, List<SPUser> users, string fieldName, bool isMultiple)
        {
            string textFieldName = "";
            if (fieldName.EndsWith("User"))
                textFieldName = fieldName.Replace("User", "");

            if (textFieldName.EndsWith("_"))
                textFieldName = fieldName.Replace("_", "");

            if (users == null)
            {
                item[fieldName] = null;
                if (!string.IsNullOrEmpty(textFieldName))
                    item[textFieldName] = "";
                return;
            }

            if (!isMultiple)
            {
                item[fieldName] = users[0].ID;
                if (!string.IsNullOrEmpty(textFieldName))
                    item[textFieldName] = users[0].Name;
            }
            else
            {
                Dictionary<string, string> result = SharePointHelper.InitilizeMultiUserFieldValue(users);
                item[fieldName] = result["Users"];
                if (!string.IsNullOrEmpty(textFieldName))
                    item[textFieldName] = result["LoginNames"];
            }
        }

        public static void UpdateUserField(SPItemEventProperties properties, List<SPUser> users, string fieldName, bool isMultiple)
        {
            string textFieldName = "";
            if (fieldName.EndsWith("User"))
                textFieldName = fieldName.Replace("User", "");

            if (textFieldName.EndsWith("_"))
                textFieldName = fieldName.Replace("_", "");

            if (users == null)
            {
                properties.AfterProperties[fieldName] = null;
                if (!string.IsNullOrEmpty(textFieldName))
                    properties.AfterProperties[textFieldName] = "";
                return;
            }

            if (!isMultiple)
            {
                properties.AfterProperties[fieldName] = users[0].ID;
                if (!string.IsNullOrEmpty(textFieldName))
                    properties.AfterProperties[textFieldName] = users[0].Name;
            }
            else
            {
                Dictionary<string, string> result = SharePointHelper.InitilizeMultiUserFieldValue(users);
                properties.AfterProperties[fieldName] = result["Users"];
                if (!string.IsNullOrEmpty(textFieldName))
                    properties.AfterProperties[textFieldName] = result["LoginNames"];
            }
        }

        public static void UpdateUserFieldByGroupAndUser(SPItemEventProperties properties, List<SPUser> users, List<SPGroup> groups, string fieldName)
        {
            string textFieldName = "";
            if (fieldName.EndsWith("User"))
                textFieldName = fieldName.Replace("User", "");

            Dictionary<string, string> userList = SharePointHelper.InitilizeMultiUserFieldValue(users);
            Dictionary<string, string> groupList = SharePointHelper.InitilizeMultiUserFieldValue(groups);

            properties.AfterProperties[fieldName] = userList["Users"] + groupList["Groups"];
            if (!string.IsNullOrEmpty(textFieldName))
                properties.AfterProperties[textFieldName] = userList["LoginNames"] + ";" + groupList["LoginNames"];
        }
        #endregion
    }
}
