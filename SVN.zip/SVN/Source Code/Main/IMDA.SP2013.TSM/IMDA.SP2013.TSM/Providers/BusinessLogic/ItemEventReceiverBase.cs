﻿using IMDA.SP2013.TSM.Providers.Helpers;
using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMDA.SP2013.TSM.Providers.BusinessLogic
{
    #region Interfaces
    public interface IDisabledItemEventsScope : IDisposable
    {
        void DisabledItemEvent();
    }
    #endregion

    public class ItemEventReceiverBase : SPItemEventReceiver, IDisabledItemEventsScope
    {
        #region Overrides
        public sealed override void ItemAdding(SPItemEventProperties properties)
        {
            Logger.LogInfo("ItemEventReceiverBase - ItemAdding (" + DateTime.Now + ")  ");
            base.ItemAdding(properties);
            this.DoItemAdding(properties);
            Logger.LogInfo("ItemEventReceiverBase - ItemAdding END (" + DateTime.Now + ")  ");
        }
        public sealed override void ItemAdded(SPItemEventProperties properties)
        {
            Logger.LogInfo("ItemEventReceiverBase - ItemAdded (" + DateTime.Now + ")  ");
            base.ItemAdded(properties);
            this.DoItemAdded(properties);
            Logger.LogInfo("ItemEventReceiverBase - ItemAdded END (" + DateTime.Now + ")  ");
        }

        public sealed override void ItemUpdating(SPItemEventProperties properties)
        {
            Logger.LogInfo("ItemEventReceiverBase - ItemUpdating (" + DateTime.Now + ")  ");
            base.ItemUpdating(properties);
            this.DoItemUpdating(properties);
            Logger.LogInfo("ItemEventReceiverBase - ItemUpdating END (" + DateTime.Now + ")  ");
        }

        public sealed override void ItemUpdated(SPItemEventProperties properties)
        {
            Logger.LogInfo("ItemEventReceiverBase - ItemUpdated (" + DateTime.Now + ")  ");
            base.ItemUpdated(properties);
            this.DoItemUpdated(properties);
            Logger.LogInfo("ItemEventReceiverBase - ItemUpdated END (" + DateTime.Now + ")  ");
        }

        public sealed override void ItemDeleted(SPItemEventProperties properties)
        {
            Logger.LogInfo("ItemEventReceiverBase - ItemDeleted (" + DateTime.Now + ")  ");
            base.ItemDeleted(properties);
            this.DoItemDeleted(properties);
            Logger.LogInfo("ItemEventReceiverBase - ItemDeleted END (" + DateTime.Now + ")  ");
        }

        public sealed override void ItemDeleting(SPItemEventProperties properties)
        {
            base.ItemDeleting(properties);
            this.DoItemDeleting(properties);
        }

        public sealed override void ItemAttachmentAdded(SPItemEventProperties properties)
        {
            Logger.LogInfo("ItemEventReceiverBase - ItemAttachmentAdded (" + DateTime.Now + ")  ");
            base.ItemAttachmentAdded(properties);
            this.DoItemAttachmentAdded(properties);
            Logger.LogInfo("ItemEventReceiverBase - ItemAttachmentAdded END (" + DateTime.Now + ")  ");
        }
        #endregion

        #region Virtuals
        protected virtual void DoItemAdding(SPItemEventProperties properties) { }
        protected virtual void DoItemAdded(SPItemEventProperties properties) { }
        protected virtual void DoItemUpdating(SPItemEventProperties properties) { }
        protected virtual void DoItemUpdated(SPItemEventProperties properties) { }
        protected virtual void DoItemDeleted(SPItemEventProperties properties) { }
        protected virtual void DoItemDeleting(SPItemEventProperties properties) { }
        protected virtual void DoItemAttachmentAdded(SPItemEventProperties properties) { }
        #endregion

        #region IDisabledItemEventsScope
        public void DisabledItemEvent()
        {
            this.EventFiringEnabled = false;
        }

        public void Dispose()
        {
            this.EventFiringEnabled = true;
        }
        #endregion
    }
}
