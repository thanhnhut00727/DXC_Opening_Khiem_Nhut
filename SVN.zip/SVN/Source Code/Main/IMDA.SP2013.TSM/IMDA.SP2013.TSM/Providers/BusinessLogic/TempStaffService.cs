﻿using IMDA.SP2013.TSM.Providers.Constants;
using IMDA.SP2013.TSM.Providers.DataAccess;
using IMDA.SP2013.TSM.Providers.Entities;
using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMDA.SP2013.TSM.Providers.BusinessLogic
{
    public class TempStaffService : IDataService<TempStaff>
    {
        public TempStaffService() { }

        public TempStaff GetById(SPWeb spweb, int recordId)
        {
            SPListItem item = SharePointHelper.GetListItem(spweb, ListNames.TempStaffs, recordId);
            if (item != null)
            {
                return new TempStaff()
                {
                    Title = item[Fields.Title].ToString(),
                    ColumnA = item[Fields.ColumnA].ToString()
                };
            }

            return null;
        }

        public int Add(SPWeb spweb, TempStaff entity) 
        {
            return 0;
        }
        public bool Update(SPWeb spweb, TempStaff entity) 
        {
            return true;
        }
        public bool Delete(SPWeb spweb, int id)
        {
            return true;
        }

        public List<TempStaff> GetAll(SPWeb spweb)
        {
            return new List<TempStaff>();
        }
    }
}
