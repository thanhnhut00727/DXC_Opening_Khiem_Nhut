﻿using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMDA.SP2013.TSM.Providers.BusinessLogic
{
    public interface IDataService<T>
        where T : class
    {
        int Add(SPWeb spweb, T entity);
        bool Update(SPWeb spweb, T entity);
        bool Delete(SPWeb spweb, int id);
        T GetById(SPWeb spweb, int id);

        List<T> GetAll(SPWeb spweb);
    }
}
