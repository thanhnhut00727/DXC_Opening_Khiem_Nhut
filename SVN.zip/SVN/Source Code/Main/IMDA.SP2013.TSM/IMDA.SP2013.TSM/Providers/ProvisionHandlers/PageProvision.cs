﻿using IMDA.SP2013.TSM.Providers.Constants;
using IMDA.SP2013.TSM.Providers.Helpers;
using IMDA.SP2013.TSM.Webparts.TempStaff.TempStaffView;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Publishing;
using Microsoft.SharePoint.WebPartPages;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls.WebParts;
using System.Xml;

namespace IMDA.SP2013.TSM.Providers.ProvisionHandlers
{
    public static class PageProvision
    {
        #region Consts
//        const string BatchDataPageCreation = @"<?xml version=""1.0"" encoding=""UTF-8""?>
//            <Method ID=""0,NewWebPage"">
//                <SetList Scope=""Request"">{0}</SetList>
//                <SetVar Name=""Cmd"">NewWebPage</SetVar>
//                <SetVar Name=""ID"">New</SetVar>
//                <SetVar Name=""Type"">WebPartPage</SetVar>
//                <SetVar Name=""WebPartPageTemplate"">1</SetVar>
//                <SetVar Name=""Overwrite"">true</SetVar>
//                <SetVar Name=""Title"">{1}</SetVar>
//            </Method>";        

//        static Guid WikiPageFeatureId = new Guid("00bfea71-d8fe-4fec-8dad-01c19a6e4053");
        #endregion

        #region Public
        public static void CreateWebPartPages(SPSite site, string filePath)
        {
            using (var web = site.OpenWeb())
            {
                CreateWebPartPages(web, filePath);
            }
        }
        /// <summary>
        /// Create WebPart pages based on configuration
        /// </summary>
        /// <param name="site"></param>
        /// <param name="filePath"></param>
        public static void CreateWebPartPages(SPWeb web, string filePath)
        {
            ////Ensure Wiki Page feature is activated
            //EnsureWebFeatureActivated(web, WikiPageFeatureId);

            //Get xml data from file path and load into xml document
            //var configData = rootWeb.GetFileAsString(filePath);
            var configData = File.ReadAllText(filePath);
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(configData);

            xmlDoc = XMLHelper.LoadXmlDocument(configData, ApplicationSettings.PagesSchema);

            //Load Site Pages list
            var listUrl = web.Url + "/Pages/Forms/AllItems.aspx";
            var list = web.GetList(listUrl);

            var elements = xmlDoc.GetElementsByTagName("Page");
            //Loop through Page element and create a Wikia page
            foreach (XmlNode pageNode in elements)
            {
                if (pageNode.Attributes["FileName"] != null)
                {
                    var pageName = pageNode.Attributes["FileName"].Value;
                    var pageLayout = pageNode.Attributes["PageLayout"].Value;
                    var pageTitle = pageNode.Attributes["PageTitle"].Value;


                    ////Create WebPart page
                    //var xml = String.Format(BatchDataPageCreation, list.ID, pageName);
                    //web.ProcessBatchData(xml);

                    ////Try to check out page
                    var webPartNode = pageNode.FirstChild;
                    var content = webPartNode.InnerXml;

                    var pageUrl = "Pages/" + pageName + ".aspx";
                    var page = web.GetFile(pageUrl);
                    if (page != null)
                    {
                        AddWebPartsToPage(web, webPartNode, page, false);
                    }
                    else //create new publishing page
                    {
                        PublishingWeb pubWeb = PublishingWeb.GetPublishingWeb(web);
                        SPContentTypeId ctId = new SPContentTypeId(ApplicationSettings.ArticlePageLayoutContentTypeId);
                        PageLayout[] pageColl = pubWeb.GetAvailablePageLayouts(ctId); // the ContentTypeId of the ContentType you used to create your pagelayout

                        // Since there might be more pagelayouts attached to our contenttype we have to select it by title
                        PageLayout selectedLayout = null;
                        foreach (PageLayout pl in pageColl)
                        {
                            if (pl.Title == pageLayout)
                            {
                                selectedLayout = pl;
                                break;
                            }
                        }

                        PublishingPage newPage = pubWeb.AddPublishingPage(pageName, selectedLayout);
                        newPage.Title = pageTitle;
                        newPage.Update();

                        var file = web.GetFile(newPage.Url);
                        if (file != null)
                        {
                            AddWebPartsToPage(web, webPartNode, file, false);
                        }
                        //newPage.ListItem.File.CheckIn("Created from code", SPCheckinType.MajorCheckIn);
                    }
                }
            }
        }
        #endregion

        #region Privates
        static void AddWebPartsToPage(SPWeb web, XmlNode webPartNode, SPFile page, bool isHomePage)
        {
            if (page.CheckedOutByUser != null) page.UndoCheckOut();
            page.CheckOut();

            //Using Web Manager to add Script Editor WebPart
            using (var wpManager = web.GetLimitedWebPartManager(page.Url, PersonalizationScope.Shared))
            {
                if (webPartNode.Attributes["Type"] != null)
                { 
                    string type = webPartNode.Attributes["Type"].Value;
                    switch(type)
                    {
                        case "TempStaffView":
                            TempStaffView tempStaffView = new TempStaffView();
                            wpManager.AddWebPart(tempStaffView, webPartNode.Attributes["WebPartZoneID"].Value, int.Parse(webPartNode.Attributes["WebPartZoneIndex"].Value));
                            break;
                        case "ContentEditorWebPart":
                            ContentEditorWebPart contentEditorWebPart = new ContentEditorWebPart();
                                XmlDocument xmlDocCW = new XmlDocument();
                                XmlElement xmlElement = xmlDocCW.CreateElement("MyElement");
                                xmlElement.InnerText = webPartNode.InnerText.Trim();

                                contentEditorWebPart.Content = xmlElement;
                                contentEditorWebPart.Title = page.Name;
                                contentEditorWebPart.ChromeType = PartChromeType.None;
                                wpManager.AddWebPart(contentEditorWebPart, webPartNode.Attributes["WebPartZoneID"].Value, int.Parse(webPartNode.Attributes["WebPartZoneIndex"].Value));
                            break;
                        default:
                            ScriptEditorWebPart scriptEditorWebPart = new ScriptEditorWebPart();
                            //var wpContent = webPartNode.InnerText.Trim();
                            //wpContent = wpContent.Replace("@SiteCollection", web.Url);
                            //webPart.Content = wpContent;
                            scriptEditorWebPart.Title = page.Name;
                            scriptEditorWebPart.ChromeType = PartChromeType.None;
                            wpManager.AddWebPart(scriptEditorWebPart, webPartNode.Attributes["WebPartZoneID"].Value, int.Parse(webPartNode.Attributes["WebPartZoneIndex"].Value));
                            break;
                    }

                    page.CheckIn(String.Empty);

                    if (isHomePage)
                    {
                        MakeHomePage(web, page.Url);
                    }
                }
            }
        }
        static void EnsureWebFeatureActivated(SPWeb web, Guid featureId)
        {
            if (!web.Features.Any(f => f.DefinitionId == featureId))
            {
                web.Features.Add(featureId);
            }
        }

        static void MakeHomePage(SPWeb web, string pageUrl)
        {
            if (PublishingWeb.IsPublishingWeb(web))
            {
                var publishingWeb = PublishingWeb.GetPublishingWeb(web);
                SPFile homePageFile = web.GetFile(pageUrl);
                publishingWeb.DefaultPage = homePageFile;
                publishingWeb.Update();
                web.Update();
            }
            else
            {
                var folder = web.RootFolder;
                folder.WelcomePage = pageUrl;
                folder.Update();
            }
        }
        #endregion
    }
}
