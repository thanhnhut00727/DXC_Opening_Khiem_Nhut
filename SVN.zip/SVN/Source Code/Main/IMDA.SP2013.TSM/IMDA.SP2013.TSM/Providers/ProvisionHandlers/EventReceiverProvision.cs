﻿using IMDA.SP2013.TSM.Providers.Entities;
using IMDA.SP2013.TSM.Providers.Helpers;
using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace IMDA.SP2013.TSM.Providers.ProvisionHandlers
{
    public class EventReceiverProvision
    {
        public static void ProvisioningEventReceiver(SPWeb spWeb, string filePath)
        {
            if (spWeb != null)
            {
                var unSafeUpdate = spWeb.AllowUnsafeUpdates;
                try
                {
                    spWeb.AllowUnsafeUpdates = true;
                    XDocument document = XMLHelper.LoadXmlFile(filePath);
                    if (document != null)
                    {
                        List<EventReceiver> receivers = XMLHelper.GetEventReceiverData(spWeb, document);
                        if (receivers.Count > 0)
                        {
                            foreach (EventReceiver item in receivers)
                            {
                                SPList list = spWeb.Lists[item.ListName];
                                if (list != null)
                                    AddEventReceiverToList(list, item);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogError(ex);
                }
                finally
                {
                    spWeb.AllowUnsafeUpdates = unSafeUpdate;
                }
            }
        }        

        private static void AddEventReceiverToList(SPList list, EventReceiver item)
        {
            if (string.IsNullOrEmpty(item.Assembly) || string.IsNullOrEmpty(item.ClassName))
                return;

            int numberOfEventsInList = list.EventReceivers.Cast<SPEventReceiverDefinition>().Count(i => i.Type == item.Type
                                                                                                      && i.Assembly == item.Assembly
                                                                                                        && i.Class == item.ClassName);

            //check existence of Event Receiver
            var numEvent = list.EventReceivers.Count;
            for (var i = numEvent - 1; i >= 0; i--)
            {
                var eventI = list.EventReceivers[i];
                if (eventI.Type == item.Type && eventI.Class == item.ClassName)
                {
                    list.EventReceivers[i].Delete();
                }
            }

            SPEventReceiverDefinition currEvent = list.EventReceivers.Add();
            currEvent.Assembly = item.Assembly;
            currEvent.Type = item.Type;
            currEvent.Class = item.ClassName;
            currEvent.Name = item.Name;
            currEvent.SequenceNumber = item.SequenceNumber;
            currEvent.Update();
        }
    }
}
