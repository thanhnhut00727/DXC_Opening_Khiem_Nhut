﻿using IMDA.SP2013.TSM.Providers.Entities;
using IMDA.SP2013.TSM.Providers.Helpers;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Navigation;
using Microsoft.SharePoint.Publishing.Navigation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace IMDA.SP2013.TSM.Providers.ProvisionHandlers
{
    public class NavigationProvision
    {
        #region Public
        public static void ConfigureNavigation(SPSite site, string fileUrl)
        {
            using (SPWeb spWeb = site.OpenWeb())
            {
                ConfigureNavigation(spWeb, fileUrl);
            }
        }

        public static void ConfigureNavigation(SPWeb spWeb, string fileUrl)
        {
            XDocument document = XMLHelper.LoadXmlFile(fileUrl);
            if (document != null)
            {
                DeleteAllQuickLaunch(spWeb);
                var navigations = XMLHelper.GetNavigationNodeData(document);
                if (navigations.Count > 0)
                {
                    foreach (var item in navigations)
                    {
                        AddTopNavigation(spWeb, item);
                    }
                }
            }

            var webNavigationSettings = new WebNavigationSettings(spWeb);
            webNavigationSettings.CurrentNavigation.Source = StandardNavigationSource.PortalProvider;
            webNavigationSettings.Update();
        }
        #endregion

        #region Private

        private static void DeleteAllQuickLaunch(SPWeb spWeb)
        {
            var spNode = spWeb.Navigation.QuickLaunch;
            var nodeCount = spNode.Count;
            for (int i = nodeCount - 1; i >= 0; i--)
            {
                spNode.Delete(spNode[i]);
                spWeb.Update();
            }
        }

        private static void AddTopNavigation(SPWeb spWeb, NavigationNode node)
        {
            var spNode = spWeb.Navigation.QuickLaunch;

            var newNode = new SPNavigationNode(node.Title, node.Url);
            spNode.AddAsLast(newNode);

            spWeb.Update();

            if (node.ChildNodes != null && node.ChildNodes.Count > 0)
            {
                AddNavigation(spWeb, node.ChildNodes, newNode);
            }

        }


        private static void AddNavigation(SPWeb spWeb, List<NavigationNode> nodes, SPNavigationNode parent)
        {
            foreach (var node in nodes)
            {
                var childNode = new SPNavigationNode(node.Title, node.Url);
                parent.Children.AddAsLast(childNode);
                parent.Update();
                spWeb.Update();
                if (node.ChildNodes != null && node.ChildNodes.Count > 0)
                {
                    AddNavigation(spWeb, node.ChildNodes, childNode);
                }
            }
        }
        #endregion
    }
}
