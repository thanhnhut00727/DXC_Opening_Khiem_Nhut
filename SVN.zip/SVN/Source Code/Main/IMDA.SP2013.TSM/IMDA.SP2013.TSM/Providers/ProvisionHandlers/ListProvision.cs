﻿using IMDA.SP2013.TSM.Providers.Constants;
using IMDA.SP2013.TSM.Providers.Entities;
using IMDA.SP2013.TSM.Providers.Helpers;
using Microsoft.SharePoint;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace IMDA.SP2013.TSM.Providers.ProvisionHandlers
{
    public class ListProvision
    {
        #region Consts
        const string ListTemplatePath = @"TEMPLATE\LAYOUTS\IMDA.SP2013.TSM\ListTemplates\";
        #endregion

        public static void ProvisionListTemplates(SPWeb spWeb, string filePath)
        {
            if (spWeb != null)
            {
                XDocument document = XMLHelper.LoadXmlFile(filePath);
                if (document != null)
                {
                    List<ListTemplate> listTemplates = XMLHelper.GetListTemplateData(document);
                    if (listTemplates.Count > 0)
                    {
                        foreach (ListTemplate list in listTemplates)
                        {
                            UploadListTemplates(spWeb, list);
                        }
                    }
                }
            }
        }       

        public static void ProvisioningList(SPWeb spWeb, string filePath)
        {
            if (spWeb != null)
            {
                var unSafeUpdate = spWeb.AllowUnsafeUpdates;
                try
                {
                    spWeb.AllowUnsafeUpdates = true;
                    XDocument document = XMLHelper.LoadXmlFile(filePath);
                    if (document != null)
                    {
                        List<ListTemplate> listTemplates = XMLHelper.GetListTemplateData(document);
                        if (listTemplates.Count > 0)
                        {
                            foreach (ListTemplate list in listTemplates)
                            {
                                if (list.IsProvisioned)
                                {
                                    //Delete list if it already exists and recreate
                                    Guid listGuid = new Guid();
                                    try
                                    {
                                        listGuid = spWeb.Lists[list.Name].ID;
                                    }
                                    catch (Exception ex)
                                    {
                                        Logger.LogError(ex);
                                    };


                                    if (listGuid != new Guid())
                                    {
                                        spWeb.Lists.Delete(listGuid);
                                    }
                                    //End of delete list if it already exists and recreate 

                                    string templateTitle = list.File.Split('.')[0];
                                    if (!string.IsNullOrEmpty(templateTitle))
                                    {
                                        Guid newListGuid = spWeb.Lists.Add(list.Name, string.Empty, 
                                            spWeb.Site.GetCustomListTemplates(spWeb)[templateTitle]);
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogError(ex);
                }
                finally
                {
                    spWeb.AllowUnsafeUpdates = unSafeUpdate;
                }
            }
        }

        #region Private Methods
        /// <summary>
        /// upload stp file and instantiate a new list based upon it
        /// </summary>
        /// <param name="web"></param>
        /// <param name="filePath"></param>
        /// <param name="templateTitle"></param>
        /// <param name="listTitle"></param>
        /// <param name="listDescription"></param>
        private static void UploadListTemplates(SPWeb web, ListTemplate list)
        {
            try
            {
                if (list.IsProvisioned)
                {
                    SPFileCollection templates = web.Folders["_catalogs"].SubFolders["lt"].Files;

                    string directoryName = ApplicationSettings.SPHiveFolder + ListTemplatePath;
                    string filePath = directoryName + list.File;
                    string templateTitle = list.File.Split('.')[0];

                    using (FileStream fs = (new System.IO.FileInfo(filePath)).OpenRead())
                    {
                        Hashtable ht = new Hashtable();
                        ht.Add("vti_title", templateTitle);
                        SPFile destfile = templates.Add(list.File, fs, ht, true);
                    }
                }
            }
            catch (Exception ex1)
            {
                Logger.LogError(ex1);
            }
        }
        #endregion
    }
}
