﻿using IMDA.SP2013.TSM.Providers.Entities;
using IMDA.SP2013.TSM.Providers.Helpers;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace IMDA.SP2013.TSM.Providers.ProvisionHandlers
{
    public static class TimerJobProvision
    {
        #region Public
        public static List<TimerJob> GetTimerJobs(SPWebApplication currentWebApp, SPSite site, string fileUrl)
        {
            List<TimerJob> jobs = null;
            using (SPWeb spWeb = site.OpenWeb())
            {
                jobs = GetTimerJobs(currentWebApp, spWeb, fileUrl);
            }

            return jobs;
        }

        public static List<TimerJob> GetTimerJobs(SPWebApplication currentWebApp, SPWeb spWeb, string fileUrl)
        {
            List<TimerJob> jobs = new List<TimerJob>();

            XDocument document = XMLHelper.LoadXmlFile(spWeb, fileUrl);
            if (document != null)
            {
                jobs = XMLHelper.GetTimerJobData(spWeb, document);
                if (jobs.Count > 0)
                {
                    foreach (TimerJob item in jobs)
                    {
                        //DeleteTimerJob(currentWebApp, item.Title);
                        item.SPSchedule = GetSPSchedule(item);
                    }
                }
            }

            return jobs;
        }

        /// <summary>
        /// Reset master page by applying SP OOTB Master Page (seatle,master)
        /// </summary>
        /// <param name="site"></param>
        public static void DeleteTimerJob(SPWebApplication currentWebApp, string jobName)
        {
            if (currentWebApp == null)
                throw new Exception("Cannot find Web Application");

            // Undeploy the job if already registered     
            var existingJobs = from SPJobDefinition job in currentWebApp.JobDefinitions
                               where job.Name == jobName
                               select job;

            if (existingJobs.Count() > 0)
                existingJobs.First().Delete();
        }

        public static SPSchedule GetSPSchedule(TimerJob jobInfo)
        {
            SPSchedule result = null;
            switch (jobInfo.ScheduleType)
            {
                case "SPDailySchedule":
                    SPDailySchedule dSchedule = new SPDailySchedule
                    {
                        BeginHour = jobInfo.BeginHour,
                        BeginMinute = jobInfo.BeginMinute,
                        BeginSecond = jobInfo.BeginSecond,
                        EndHour = jobInfo.EndHour,
                        EndMinute = jobInfo.EndMinute,
                        EndSecond = jobInfo.EndSecond
                    };

                    result = (SPSchedule)dSchedule;
                    break;
                case "SPMonthlySchedule":
                    SPMonthlySchedule mSchedule = new SPMonthlySchedule
                    {
                        BeginDay = jobInfo.BeginDay,
                        BeginHour = jobInfo.BeginHour,
                        BeginMinute = jobInfo.BeginMinute,
                        BeginSecond = jobInfo.BeginSecond,
                        EndHour = jobInfo.EndHour,
                        EndMinute = jobInfo.EndMinute,
                        EndSecond = jobInfo.EndSecond
                    };

                    result = (SPSchedule)mSchedule;
                    break;
                case "SPHourlySchedule":
                case "SPMinuteSchedule":
                case "SPOneTimeSchedule":
                case "SPYearlySchedule":
                case "SPWeeklySchedule":
                default:
                    break;
            }

            return result;
        }
        #endregion
    }
}
