﻿using IMDA.SP2013.TSM.Providers.DataAccess;
using IMDA.SP2013.TSM.Providers.Entities;
using IMDA.SP2013.TSM.Providers.Helpers;
using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace IMDA.SP2013.TSM.Providers.ProvisionHandlers
{
    public class PermissionProvision
    {
        public static void ProvisioningPermission(SPSite site, string fileUrl)
        {
            using (SPSite spSite = new SPSite(site.ID))
            {
                SPWeb spWeb = site.RootWeb;
                ProvisioningPermission(spWeb, fileUrl);
            }
        }
        public static void ProvisioningPermission(SPWeb spWeb, string filePath)
        {
            var unSafeUpdate = spWeb.AllowUnsafeUpdates;
            try
            {
                spWeb.AllowUnsafeUpdates = true;
                XDocument document = XMLHelper.LoadXmlFile(filePath);
                if (document != null)
                {
                    List<Group> permissions = XMLHelper.GetPermissionData(spWeb, document);
                    if (permissions.Count > 0)
                    {
                        ////string listName = permissions[0].ListName;
                        ////SPList list = spWeb.Lists[listName];

                        foreach (Group item in permissions)
                        {
                            ////if (!listName.Equals(item.ListName))
                            ////{
                            ////    list = spWeb.Lists[item.ListName];
                            ////    listName = item.ListName;
                            ////}

                            ////if (list != null)
                            ////{
                                SPGroup group = AddorUpdateSecurityGroup(spWeb.Site, item);
                            //    //if (group != null)
                            //        //AddorUpdateSecurityGroupToList(spWeb, list, item);
                            ////}
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex);
            }
            finally
            {
                spWeb.AllowUnsafeUpdates = unSafeUpdate;
            }
        }

        #region Private Functions
        private static SPRoleType GetSPRoleType(string roleType)
        {
            SPRoleType result = SPRoleType.None;
            switch (roleType)
            {
                case "Full Control":
                    result = SPRoleType.Administrator;
                    break;
                case "Contribute":
                    result = SPRoleType.Editor;
                    break;
                case "Read":
                    result = SPRoleType.Reader;
                    break;
                default:
                    break;
            }

            return result;
        }

        private static SPGroup AddorUpdateSecurityGroup(SPSite site, Group grInfo)
        {
            SPWeb root = site.RootWeb;
            SPGroup group = null;

            // Check if the group exists
            try
            {
                group = root.SiteGroups[grInfo.Name];
            }
            catch { }

            // If it doesn't, add it
            if (group == null)
            {
                SPMember oMember = root.AllUsers[grInfo.OwnerAlias];
                root.SiteGroups.Add(grInfo.Name, oMember, root.Author, grInfo.Name);

                group = root.SiteGroups[grInfo.Name];

                if (group != null)
                {
                    // Add the group's permissions
                    SPRoleDefinition roleDefinition = root.RoleDefinitions.GetByType(GetSPRoleType(grInfo.Role));
                    SPRoleAssignment roleAssignment = new SPRoleAssignment(group);
                    roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                    root.RoleAssignments.Add(roleAssignment);
                    root.Update();

                    grInfo.RoleDefinition = roleDefinition;
                    grInfo.RoleAssignment = roleAssignment;
                }
            }
            else
            {
                SPRoleDefinition roleDefinition1 = root.RoleDefinitions.GetByType(GetSPRoleType(grInfo.Role));
                SPRoleAssignment roleAssignment1 = new SPRoleAssignment(group);

                grInfo.RoleDefinition = roleDefinition1;
                grInfo.RoleAssignment = roleAssignment1;
            }

            return group;
        }

        private static SPRoleAssignment RemoveExistingGroupInList(SPList list, SPPrincipal principal, Group group)
        {
            SPRoleAssignment assignmentForGroup = null;
            try
            {
                assignmentForGroup = list.RoleAssignments.GetAssignmentByPrincipal(principal);
                if (assignmentForGroup != null)
                    assignmentForGroup.RoleDefinitionBindings.Remove(group.RoleDefinition);
            }
            catch
            {
            }

            return assignmentForGroup;
        }

        private static void AddorUpdateSecurityGroupToList(SPWeb web, SPList list, Group group)
        {
            if (!list.HasUniqueRoleAssignments) // required to make role change
                list.BreakRoleInheritance(true);

            SPPrincipal principal = SharePointHelper.GetPrinciple(web, group.Name);
            if (principal != null)
            {
                try
                {
                    var assignmentForGroup = RemoveExistingGroupInList(list, principal, group);
                    if (assignmentForGroup == null)
                    {
                        list.RoleAssignments.Add(principal);
                        assignmentForGroup = list.RoleAssignments.GetAssignmentByPrincipal(principal);
                    }

                    assignmentForGroup.RoleDefinitionBindings.Add(group.RoleDefinition);
                    assignmentForGroup.Update();
                }
                catch { }
            }
        }
        #endregion
    }
}
