﻿using IMDA.SP2013.TSM.Providers.Constants;
using IMDA.SP2013.TSM.Providers.Helpers;
using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMDA.SP2013.TSM.Providers.ProvisionHandlers
{
    public class MasterPageProvision
    {
        #region Public
        /// <summary>
        /// Set master page
        /// </summary>
        /// <param name="site"></param>
        /// <param name="masterPage"></param>
        public static void SetMasterPage(SPWeb spWeb, string masterPage)
        {
            ApplyMasterPage(spWeb, masterPage);
        }

        /// <summary>
        /// Reset master page by applying SP OOTB Master Page (seatle,master)
        /// </summary>
        /// <param name="site"></param>
        public static void ResetMasterPage(SPWeb spWeb)
        {
            ApplyMasterPage(spWeb);
        }

        public static void DeleteBrandingFolder(SPWeb spWeb, string folderName)
        {
            var folder = spWeb.Lists.TryGetList(ListNames.SiteAssets).RootFolder.SubFolders[folderName];
            if (folder != null)
            {
                folder.Delete();
            }
        }
        #endregion

        #region Privates
        /// <summary>
        /// Apply master page with master page name
        /// </summary>
        /// <param name="site"></param>
        /// <param name="masterPage"></param>
        private static void ApplyMasterPage(SPWeb spWeb, string masterPage = null)
        {
            if (String.IsNullOrEmpty(masterPage))
            {
                masterPage = ApplicationSettings.DefaultMasterPage;
            }

            // Calculate relative path to site from Web Application root.
            string webAppRelativePath = spWeb.ServerRelativeUrl;
            if (!webAppRelativePath.EndsWith("/"))
            {
                webAppRelativePath += "/";
            }

            // Enumerate through each site and apply branding.
            //foreach (SPWeb web in site.AllWebs)
            //{
                try
                {
                    ////spWeb.MasterUrl = webAppRelativePath + "_catalogs/masterpage/" + masterPage;
                    spWeb.CustomMasterUrl = webAppRelativePath + "_catalogs/masterpage/" + masterPage;

                    spWeb.Update();

                    if (String.IsNullOrEmpty(masterPage))
                    {
                        DeleteBrandingFolder(spWeb, ApplicationSettings.SiteBrandingFolder);
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogError(ex);
                }
                finally
                {
                    if (spWeb != null)
                        spWeb.Dispose();
                }
            
            //}
        }
        #endregion
    }
}
