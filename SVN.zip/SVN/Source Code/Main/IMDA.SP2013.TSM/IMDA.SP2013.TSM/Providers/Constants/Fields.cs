﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMDA.SP2013.TSM.Providers.Constants
{
    public static class Fields
    {
        //Common Fields
        public const string Title = "Title";
        public const string Id = "ID";
        public const string Author = "Author";
        public const string Editor = "Editor";
        public const string Created = "Created";
        public const string Modified = "Modified";
        public const string ContentTypeId = "ContentTypeId";

        //Keywords
        public const string KeywordValues = "KeywordValues";

        //Temp Staff
        public const string ColumnA = "ColumnA";
        
    }
}
