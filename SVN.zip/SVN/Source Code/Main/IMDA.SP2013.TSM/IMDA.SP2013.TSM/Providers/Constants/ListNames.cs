﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMDA.SP2013.TSM.Providers.Constants
{
    public static class ListNames
    {
        public const string Keywords = "Keywords";
        public const string TempStaffs = "Temp Staffs";
        public const string StyleLibrary = "Site Assets";
        public const string SiteAssets = "Site Assets";
    }
}
