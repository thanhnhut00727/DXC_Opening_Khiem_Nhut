﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMDA.SP2013.TSM.Providers.Constants
{
    public static class ApplicationSettings
    {
        public const string MetadataPath = @"TEMPLATE\LAYOUTS\IMDA.SP2013.TSM\Metadata\";
        public const string SPHiveFolder = @"C:\Program Files\Common files\Microsoft Shared\Web Server Extensions\15\";

        public const string DefaultMasterPage = "seattle.master";
        public const string TSMMasterPage = "tsm.master";
        public const string SiteBrandingFolder = "TSM";
        public const string ArticlePageLayoutContentTypeId = "0x010100C568DB52D9D0A14D9B2FDCC96666E9F2007948130EC3DB064584E219954237AF3900242457EFB8B24247815D688C526CD44D";
        public const string ScriptEditorWebPart = @"<?xml version=""1.0"" encoding=""utf-8""?>
                        <webParts>
	                        <webPart xmlns=""http://schemas.microsoft.com/WebPart/v3"">
		                        <metaData>
			                        <type name=""Microsoft.SharePoint.WebPartPages.ScriptEditorWebPart, Microsoft.SharePoint, Version=15.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c"" />
			                        <importErrorMessage>Cannot import this Web Part.</importErrorMessage>
		                        </metaData>
		                        <data>
			                        <properties>
				                        <property name=""Title"" type=""string"">$pageName</property>
				                        <property name=""Description"" type=""string"">$pageName</property>
				                        <property name=""ChromeType"" type=""chrometype"">None</property>
				                        <property name=""Content"" type=""string""><![CDATA[{0}]]></property>
			                        </properties>
		                        </data>
	                        </webPart>
                        </webParts>";
        public const string PagesSchema = @"<xs:schema attributeFormDefault=""unqualified"" elementFormDefault=""qualified="" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
                                            <xs:element name=""Web="">
                                                <xs:complexType>
                                                  <xs:sequence>
                                                    <xs:element name=""Data"">
                                                      <xs:complexType>
                                                        <xs:sequence>
                                                          <xs:element name=""Pages"">
                                                            <xs:complexType>
                                                              <xs:sequence>
                                                                <xs:element name=""Page"">
                                                                  <xs:complexType>
                                                                    <xs:sequence>
                                                                      <xs:element name=""WebPart"">
                                                                        <xs:complexType>
                                                                          <xs:attribute name=""Type"" type=""xs:string"" use=""required"" />
                                                                          <xs:attribute name=""WebPartZoneID"" type=""xs:string"" use=""required"" />
                                                                          <xs:attribute name=""WebPartZoneIndex"" type=""xs:unsignedByte"" use=""required"" />
                                                                          <xs:attribute name=""Title"" type=""xs:string"" use=""required"" />
                                                                        </xs:complexType>
                                                                      </xs:element>
                                                                    </xs:sequence>
                                                                    <xs:attribute name=""PageLayout"" type=""xs:string"" use=""required"" />
                                                                    <xs:attribute name=""FileName"" type=""xs:string"" use=""required"" />
                                                                    <xs:attribute name=""WelcomePage"" type=""xs:boolean"" use=""required"" />
                                                                    <xs:attribute name=""PageTitle"" type=""xs:string"" use=""required"" />
                                                                  </xs:complexType>
                                                                </xs:element>
                                                              </xs:sequence>
                                                            </xs:complexType>
                                                          </xs:element>
                                                        </xs:sequence>
                                                      </xs:complexType>
                                                    </xs:element>
                                                  </xs:sequence>
                                                  <xs:attribute name=""Url"" type=""xs:string"" use=""required"" />
                                                </xs:complexType>
                                              </xs:element>
                                            </xs:schema>";
    }
}
