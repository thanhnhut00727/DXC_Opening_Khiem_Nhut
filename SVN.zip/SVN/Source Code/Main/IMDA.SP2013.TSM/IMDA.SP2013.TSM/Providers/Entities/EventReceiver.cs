﻿using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMDA.SP2013.TSM.Providers.Entities
{
    public class EventReceiver
    {
        public string ListName { get; set; }
        public string Assembly { get; set; }
        public string ClassName { get; set; }
        public string Name { get; set; }
        public int SequenceNumber { get; set; }
        public SPEventReceiverType Type { get; set; }
    }
}
