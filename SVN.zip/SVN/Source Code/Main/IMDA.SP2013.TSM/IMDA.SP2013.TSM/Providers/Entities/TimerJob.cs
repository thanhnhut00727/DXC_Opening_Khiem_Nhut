﻿using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMDA.SP2013.TSM.Providers.Entities
{
    public class TimerJob
    {
        public string Name { get; set; }
        public string Title { get; set; }
        public string Namespace { get; set; }
        public string ScheduleType { get; set; }
        public SPSchedule SPSchedule { get; set; }
        public int BeginDay { get; set; }
        public int BeginHour { get; set; }
        public int EndHour { get; set; }
        public int BeginMinute { get; set; }
        public int EndMinute { get; set; }
        public int BeginSecond { get; set; }
        public int EndSecond { get; set; }
    }
}
