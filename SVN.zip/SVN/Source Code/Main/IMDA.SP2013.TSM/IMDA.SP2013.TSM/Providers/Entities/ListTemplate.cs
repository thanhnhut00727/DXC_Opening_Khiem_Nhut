﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMDA.SP2013.TSM.Providers.Entities
{
    public class ListTemplate
    {
        public string Name { get; set; }
        public string File { get; set; }
        public bool IsProvisioned { get; set; }
    }
}
