﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMDA.SP2013.TSM.Providers.Entities
{
    public class NavigationNode
    {
        //public int Id { get; set; }
        //public int ParentId { get; set; }
        public string Title { get; set; }
        public string Url { get; set; }
        public List<NavigationNode> ChildNodes { get; set; }
    }
}
