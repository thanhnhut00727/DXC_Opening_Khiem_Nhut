﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMDA.SP2013.TSM.Providers.Entities
{
    public class TempStaff
    {
        public string Title { get; set; }
        public string ColumnA { get; set; }
    }
}
