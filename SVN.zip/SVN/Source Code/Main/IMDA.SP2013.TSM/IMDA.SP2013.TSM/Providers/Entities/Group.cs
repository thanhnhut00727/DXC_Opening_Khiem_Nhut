﻿using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMDA.SP2013.TSM.Providers.Entities
{
    public class Group
    {
        public string Name { get; set; }
        public string ListName { get; set; }
        public string Role { get; set; }
        public string OwnerAlias { get; set; }
        public SPRoleDefinition RoleDefinition { get; set; }
        public SPRoleAssignment RoleAssignment { get; set; }
    }
}
