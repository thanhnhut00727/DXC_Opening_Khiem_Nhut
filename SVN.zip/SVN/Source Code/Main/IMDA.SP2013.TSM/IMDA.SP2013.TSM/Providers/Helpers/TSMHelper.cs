﻿using IMDA.SP2013.TSM.Providers.Constants;
using IMDA.SP2013.TSM.Providers.DataAccess;
using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace IMDA.SP2013.TSM.Providers.Helpers
{
    public static class TSMHelper
    {
        private static string _rowDelimeter = ";#";
        private static string _colDelimeter = ";!";

        public static string GetKeyword(SPWeb web, string key)
        {
            SPQuery qry = new SPQuery();
            qry.Query = String.Format(@"
                       <Where>       
                                <Eq>
                                    <FieldRef Name='{0}'/>
                                    <Value Type='Text'>{1}</Value>
                                </Eq>   
                             
                        </Where>",
                        Fields.Title,
                        key);
            qry.RowLimit = 1;

            SPListItem item = SharePointHelper.QueryListItem(web, ListNames.Keywords, qry);
            if (item != null && item[Fields.KeywordValues] != null)
            {
                string result = item[Fields.KeywordValues].ToString();
                return Regex.Replace(result, "<.*?>", string.Empty);
            }

            return string.Empty;
        }

        private static string GetValueOfRichTextField(SPListItem listItem, string fieldName)
        {
            SPFieldMultiLineText spFieldMultiLineText = listItem[fieldName] as SPFieldMultiLineText;
            return spFieldMultiLineText.GetFieldValueAsText(listItem[fieldName]);
        }
    }
}
