﻿using Microsoft.SharePoint.Administration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMDA.SP2013.TSM.Providers.Helpers
{
    public class Logger
    {
        const string ERROR_CATEGORY = "TSMIMDA";
        public static void LogInfo(string message)
        {
            Log(ERROR_CATEGORY, message, string.Empty, string.Empty, EventSeverity.Information);
        }
        public static void LogError(Exception ex)
        {
            Log(ERROR_CATEGORY, ex.Message, ex.StackTrace, string.Empty, EventSeverity.Error);
        }
        public static void Log(string category, string message, string strackTrace, string errorPrefix, EventSeverity serverity)
        {
            try
            {
                SPDiagnosticsService diagSvc = SPDiagnosticsService.Local;
                diagSvc.WriteTrace(0, new SPDiagnosticsCategory(ERROR_CATEGORY, TraceSeverity.Monitorable, serverity),
                    TraceSeverity.Monitorable, "Writing to the ULS log:  {0} {1} {2}", errorPrefix, message, strackTrace);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Error while writing log: " + message);
                System.Diagnostics.Debug.WriteLine(ex);
            }
        }
    }
}
