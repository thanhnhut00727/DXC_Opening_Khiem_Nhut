﻿using IMDA.SP2013.TSM.Providers.Constants;
using IMDA.SP2013.TSM.Providers.Entities;
using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;

namespace IMDA.SP2013.TSM.Providers.Helpers
{
    public static class XMLHelper
    {
        public static XDocument LoadXmlFile(string filePath)
        {
            XDocument document = new XDocument();            
            using (StreamReader file = new StreamReader(filePath))
            {
                document = XDocument.Load(file);
            }

            return document;
        }
        public static XDocument LoadXmlFile(SPWeb spWeb, string fileUrl)
        {
            XDocument document = new XDocument();
            SPFile file = spWeb.GetFile(fileUrl);
            if (file != null)
            {
                byte[] bytes = file.OpenBinary();
                Stream stream = new MemoryStream(bytes);
                document = XDocument.Load(new StreamReader(stream));
                stream.Close();
            }

            return document;
        }

        public static List<ListTemplate> GetListTemplateData(XDocument xDoc)
        {
            var results = new List<ListTemplate>();

            results = xDoc.Root.Elements().Elements().Elements().Select(element =>
                new ListTemplate
                {
                    Name = (element.Attribute("Name") != null ? element.Attribute("Name").Value : string.Empty),
                    File = (element.Attribute("File") != null ? element.Attribute("File").Value : string.Empty),
                    IsProvisioned = (element.Attribute("IsProvisioned") != null ? Convert.ToBoolean(element.Attribute("IsProvisioned").Value) : false)
                }).ToList();
            return results;
        }

        public static List<EventReceiver> GetEventReceiverData(SPWeb spWeb, XDocument xDoc)
        {
            List<EventReceiver> results = new List<EventReceiver>();

            foreach (var parentNode in xDoc.Descendants("Receivers"))
            {
                string listName = (parentNode.Attribute("ListName") != null) ? parentNode.Attribute("ListName").Value : string.Empty;

                List<EventReceiver> nodes = (from doc in parentNode.Descendants("Receiver")
                                                 select new EventReceiver
                                                 {
                                                     ListName = listName,
                                                     Assembly = (doc.Element("Assembly") != null) ? doc.Element("Assembly").Value : string.Empty,
                                                     ClassName = (doc.Element("Class") != null) ? doc.Element("Class").Value : string.Empty,
                                                     Name = (doc.Element("Name") != null) ? doc.Element("Name").Value : string.Empty,
                                                     SequenceNumber = (doc.Element("SequenceNumber") != null) ? int.Parse(doc.Element("SequenceNumber").Value) : 1,
                                                     Type = (SPEventReceiverType)Enum.Parse(typeof(SPEventReceiverType), (doc.Element("Type") != null) ? doc.Element("Type").Value : string.Empty)
                                                 }).ToList();

                if (nodes != null && nodes.Count > 0)
                    results.AddRange(nodes);
            }

            return results;
        }        

        public static List<NavigationNode> GetNavigationNodeData(XDocument xDoc)
        {
            var results = new List<NavigationNode>();

            results = xDoc.Root.Elements().Elements().Elements().Select(element =>
                new NavigationNode
                {
                    Title = (element.Attribute("Title") != null ? element.Attribute("Title").Value : string.Empty),
                    Url = (element.Attribute("Url") != null ? element.Attribute("Url").Value : string.Empty),
                    ChildNodes = element.Elements().Select(newvalue => Parse(newvalue)).ToList()
                }).ToList();
            return results;
        }

        public static Dictionary<string, string> GetDefaultData(SPWeb spWeb, XDocument xDoc)
        {
            Dictionary<string, string> results = new Dictionary<string, string>();

            foreach (var parentNode in xDoc.Descendants("Key"))
            {
                string key = (parentNode.Attribute("Name") != null) ? parentNode.Attribute("Name").Value : string.Empty;
                string value = (parentNode.Attribute("Value") != null) ? parentNode.Attribute("Value").Value : string.Empty;
                results.Add(key, value);
            }

            return results;
        }

        //Xml validatiom: Missing XML Validation
        public static XmlDocument LoadXmlDocument(string xmlString, string schemaString)
        {
            XmlSchema schema = XmlSchema.Read(new StringReader(schemaString),
                (sender, args) => { throw args.Exception; });
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.Schemas.Add(schema);
            settings.ValidationType = ValidationType.Schema;
            settings.DtdProcessing = DtdProcessing.Prohibit;
            settings.XmlResolver = null;

            XmlDocument xmlDoc = new XmlDocument();
            using (StringReader stringReader = new StringReader(xmlString))
            {
                using (XmlReader xmlReader = XmlReader.Create(stringReader, settings))
                {
                    xmlDoc.Load(xmlReader);
                }
            }
            return xmlDoc;
        }

        public static List<Group> GetPermissionData(SPWeb spWeb, XDocument xDoc)
        {
            List<Group> results = new List<Group>();

            foreach (var parentNode in xDoc.Descendants("Permissions"))
            {
                //string listName = (parentNode.Attribute("ListName") != null) ? parentNode.Attribute("ListName").Value : string.Empty;
                string ownerAlias = (parentNode.Attribute("OwnerAlias") != null) ? parentNode.Attribute("OwnerAlias").Value : string.Empty;

                List<Group> nodes = (from doc in parentNode.Descendants("Group")
                                         select new Group
                                                 {
                                                     //ListName = listName,
                                                     OwnerAlias = ownerAlias,
                                                     Name = (doc.Attribute("Name") != null) ? doc.Attribute("Name").Value : string.Empty,
                                                     Role = (doc.Attribute("Role") != null) ? doc.Attribute("Role").Value : string.Empty
                                                 }).ToList();

                if (nodes != null && nodes.Count > 0)
                    results.AddRange(nodes);
            }

            return results;
        }

        #region Private        
        private static string GetQuery(XElement query)
        {
            var reader = query.CreateReader();
            reader.MoveToContent();
            return reader.ReadInnerXml();

        }

        private static NavigationNode Parse(XElement element)
        {
            return new NavigationNode
            {
                Title = (element.Attribute("Title") != null ? element.Attribute("Title").Value : string.Empty),
                Url = (element.Attribute("Url") != null ? element.Attribute("Url").Value : string.Empty),
                ChildNodes = element.Elements().Select(newvalue => Parse(newvalue)).ToList()


            };
        }

        #endregion
    }
}
