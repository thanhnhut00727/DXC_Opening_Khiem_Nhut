﻿using IMDA.SP2013.TSM.Providers.BusinessLogic;
using IMDA.SP2013.TSM.Providers.Constants;
using IMDA.SP2013.TSM.Providers.DataAccess;
using IMDA.SP2013.TSM.Providers.Helpers;
using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMDA.SP2013.TSM.EventReceivers
{
    public class TempStaffsEventReceiver : ItemEventReceiverBase
    {
        #region Common Variables
        private string _listItemUrl;
        private Dictionary<string, string> _fields;

        private List<string> _internalFields = new List<string> { Fields.Title,                                                                    
                                                                    Fields.Editor,
                                                                    Fields.Author,
                                                                    Fields.ColumnA
        };
        #endregion

        #region Overrides
        protected override void DoItemAdded(SPItemEventProperties properties)
        {
            StartTempStaffWorkflow(properties);
        }        
        #endregion

        #region Privates
        void StartTempStaffWorkflow(SPItemEventProperties properties)
        {
            this.EventFiringEnabled = false;
            SPUser sysAccount = properties.Site.SystemAccount;
            using (SPSite site = new SPSite(properties.Site.Url, sysAccount.UserToken))
            {
                using (SPWeb web = site.OpenWeb())
                {
                    bool allowUnsafe = web.AllowUnsafeUpdates;
                    try
                    {
                        web.AllowUnsafeUpdates = true;

                        InitilizeParameters(web);
                        _fields = new Dictionary<string, string>();
                        SharePointHelper.GetFieldValues(_fields, properties, _internalFields);

                        string webRelativeUrl = properties.RelativeWebUrl;
                        _listItemUrl = SharePointHelper.GetListItemUrl(properties.ListItem, webRelativeUrl);

                        //update ColumnA = list item url
                        properties.ListItem[Fields.ColumnA] = _listItemUrl;
                        properties.ListItem.Update();
                    }
                    catch (Exception ex)
                    {
                        Logger.LogError(ex);
                    }
                    finally
                    {
                        web.AllowUnsafeUpdates = allowUnsafe;
                        this.EventFiringEnabled = true;
                    }
                }
            }
        }

        void InitilizeParameters(SPWeb web)
        {
            //TODO: get system configuration from Keywords list
            //_listName = TMSHelper.GetKeyword(web, ListNames.Keywords);
        }
        #endregion
    }
}
