﻿namespace IMDA.SP2013.TSM.Webparts.TempStaff.TempStaffEntry
{
    public partial class TempStaffEntryUserControl
    {
    }
}
