﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace IMDA.SP2013.TSM.Webparts.TempStaff.TempStaffEntry
{
    public partial class TempStaffEntryUserControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}
