﻿using IMDA.SP2013.TSM.Providers.BusinessLogic;
using Microsoft.SharePoint;
using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace IMDA.SP2013.TSM.Webparts.TempStaff.TempStaffView
{
    public partial class TempStaffViewUserControl : UserControl
    {
        #region Variables
        private int _recID;
        private TempStaffService _tempStaffService;
        private IMDA.SP2013.TSM.Providers.Entities.TempStaff _currentRecord;
        private string _prevUrl;
        #endregion

        #region Properties
        public string CurrentWebURL
        {
            get { return SPContext.Current.Web.Url; }
        }
        #endregion

        protected override void OnInit(EventArgs e)
        {
            _recID = int.MinValue;
            base.OnInit(e);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Page.Request.QueryString["recid"]))
            {
                string recId = Page.Request.QueryString["recid"].ToString();
                _prevUrl = Page.Request.QueryString["form"].ToString();

                bool isInt = int.TryParse(recId, out _recID);
                if (!isInt)
                {
                    RedirectToPrevPage();
                }
            }

            if (!Page.IsPostBack && (_recID > int.MinValue))
            {
                _tempStaffService = new TempStaffService();
                _currentRecord = _tempStaffService.GetById(SPContext.Current.Web, _recID);
                PopulateData();
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            RedirectToPrevPage();
        }

        #region Private Methods
        private void PopulateData()
        {
            if (_currentRecord != null)
            {
                lblTitle.Text = _currentRecord.Title;
                lblColumnA.Text = _currentRecord.ColumnA;
            }
        }

        private void RedirectToPrevPage()
        {
            if (!string.IsNullOrEmpty(_prevUrl))
                Page.Response.Redirect(_prevUrl);
        }
        #endregion
    }
}
