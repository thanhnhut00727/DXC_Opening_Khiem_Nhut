﻿using IMDA.SP2013.TSM.Providers.Helpers;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMDA.SP2013.TSM.TimerJobs
{
    public class PriorContractEndTimerJob : SPJobDefinition
    {
        #region Properties
        [Persisted]
        public string HomeSiteUrl;
        #endregion

        #region Constructors
        public PriorContractEndTimerJob()
            : base() { }

        public PriorContractEndTimerJob(string name, SPService service, SPServer server, SPJobLockType lockType)
            : base(name, service, server, lockType) { }

        public PriorContractEndTimerJob(string name, SPWebApplication webApplication)
            : base(name, webApplication, null, SPJobLockType.ContentDatabase)
        {
            this.Title = name;
        }
        #endregion

        #region Overrides
        public override void Execute(Guid targetInstanceId)
        {
            if (!string.IsNullOrEmpty(this.Properties["HomeSiteUrl"].ToString()))
                HomeSiteUrl = this.Properties["HomeSiteUrl"].ToString();

            var webApplication = this.Parent as SPWebApplication;
            var contentDatabase = webApplication.ContentDatabases[targetInstanceId];

            using (var site = new SPSite(HomeSiteUrl))
            {
                using (SPWeb web = site.OpenWeb())
                {
                    if (web != null)
                    {
                        bool allowUnsafe = web.AllowUnsafeUpdates;
                        try
                        {
                            //TODO: implement business logic of timer job
                        }
                        catch (Exception ex)
                        {
                            Logger.LogError(ex);
                        }
                        finally
                        {
                            web.AllowUnsafeUpdates = allowUnsafe;
                        }
                    }
                }
            }
        }
        #endregion
    }
}
