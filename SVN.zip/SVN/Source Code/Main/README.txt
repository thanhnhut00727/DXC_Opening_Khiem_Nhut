1. Create a site collection and a sub-site
2. Turn on publishing feature for both site collection and sub-site
2. Upload master page of IMDA to master page gallery of site collection
3. Upload all Style Library of IMDA to site collection using SPFileZilla tool
4. Configure site collection to use IMDA master page for site master page and system master page
5. Configure sub-site to use IMDA master page for system master page
6. Deploy TSM package



https://github.com/bandrben/SPFileZilla2013